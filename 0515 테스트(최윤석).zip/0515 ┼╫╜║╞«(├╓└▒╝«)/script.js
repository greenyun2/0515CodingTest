let isStarted = false;
const target = document.querySelector("#");
const button = document.querySelector("#");
const number = document.querySelector("#");
const btn = document.querySelector("#");

button.addEventListener("click", (e) => {
  e.preventDefault();

  if(isStarted === false) {

    isStarted = true;
    const token = String(Math.floor(Math.random() * 1000000)).padStart(6, "0");
    target.innerText = token;
    target.style.color = "#" + token;
  
    let time = 180;

    setInterval(function() {
      if(time >= 0) {
        let min = Math.floor(time / 60);
        let sec = String(time % 60).padStart(2, "0")
        time = time - 1
        number.innerText = (min + " : " + sec) 
      } else {
        btn.disabled = true;
        isStarted = false;
      }    
    }, 1000);
  } 

});

const check = function() {
  let phoneNumber1 = document.querySelector("#").value;
  let phoneNumber2 = document.querySelector("#").value;
  let phoneNumber3 = document.querySelector("#").value;

  if(phoneNumber1 !== "" && phoneNumber2  !== "" && phoneNumber3 !== "" ) {
    document.querySelector("#").disabled = false
  } else {
    document.querySelector("#").disabled = true
  }
}